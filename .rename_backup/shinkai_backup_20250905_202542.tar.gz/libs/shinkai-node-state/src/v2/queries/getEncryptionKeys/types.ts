export type Encryptionkeys = {
  profile_encryption_pk: string;
  profile_encryption_sk: string;

  profile_identity_pk: string;
  profile_identity_sk: string;
};
