export type GetNodeStorageLocationInput = {
  nodeAddress: string;
  token: string;
};
