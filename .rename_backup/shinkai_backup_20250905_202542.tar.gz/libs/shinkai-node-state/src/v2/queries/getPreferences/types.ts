export type GetPreferencesInput = {
  nodeAddress: string;
  token: string;
};
