import translation from './default';

const resources = {
  translation,
} as const;

export default resources;
