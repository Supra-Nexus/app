# hanzo-message-ts

This library was generated with [Nx](https://nx.dev).

## Building

Run `nx build hanzo-message-ts` to build the library.

## Running unit tests

Run `nx test hanzo-message-ts` to execute the unit tests via [Jest](https://jestjs.io).
