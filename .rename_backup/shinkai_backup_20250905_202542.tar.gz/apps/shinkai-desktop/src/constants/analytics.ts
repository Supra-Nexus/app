export const analyticsBulletPoints = () => [
  'analytics.bulletPoints.one' as const,
  'analytics.bulletPoints.two' as const,
  'analytics.bulletPoints.three' as const,
  'analytics.bulletPoints.four' as const,
  'analytics.bulletPoints.five' as const,
  'analytics.bulletPoints.six' as const,
];
