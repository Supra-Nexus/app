export const HOME_PATH = '/';
export const ONBOARDING_PATH = '/onboarding';
export const CHAT_PATH = '/chat';
export const SETTINGS_PATH = '/settings';
export const ADD_AGENT_PATH = '/add-ai';

export const CREATE_CHAT_PATH = '/create-chat';
export const GENERATE_CODE_PATH = '/generate-code';
export const EXPORT_CONNECTION = '/export-connection';
export const INBOXES = '/inboxes';
export const MCP_SERVERS = '/mcp-servers';