import {
  Tooltip,
  TooltipContent,
  TooltipPortal,
  TooltipProvider,
  TooltipTrigger,
} from '@hanzo_network/hanzo-ui';
import { PromptLibraryIcon } from '@hanzo_network/hanzo-ui/assets';
import { cn } from '@hanzo_network/hanzo-ui/utils';
import { memo } from 'react';

import { usePromptSelectionStore } from '../../prompt/context/prompt-selection-context';
import { actionButtonClassnames } from '../conversation-footer';

function PromptSelectionActionBarBase({
  disabled,
  showLabel,
}: {
  disabled?: boolean;
  showLabel?: boolean;
}) {
  const setPromptSelectionDrawerOpen = usePromptSelectionStore(
    (state) => state.setPromptSelectionDrawerOpen,
  );

  if (!showLabel) {
    return (
      <TooltipProvider delayDuration={0}>
        <Tooltip>
          <TooltipTrigger asChild>
            <button
              className={cn(actionButtonClassnames)}
              disabled={disabled}
              onClick={() => {
                setPromptSelectionDrawerOpen(true);
              }}
              type="button"
            >
              <PromptLibraryIcon className="h-full w-full" />
            </button>
          </TooltipTrigger>
          <TooltipPortal>
            <TooltipContent align="center" side="top">
              Prompt Library
            </TooltipContent>
          </TooltipPortal>
        </Tooltip>
      </TooltipProvider>
    );
  }
  return (
    <button
      className={cn(actionButtonClassnames, 'w-full justify-start gap-2.5')}
      disabled={disabled}
      onClick={() => {
        setPromptSelectionDrawerOpen(true);
      }}
      type="button"
    >
      <PromptLibraryIcon className="size-4" />
      <span className="">Prompt Library</span>
    </button>
  );
}

const PromptSelectionActionBar = memo(
  PromptSelectionActionBarBase,
  (prevProps, nextProps) => {
    return prevProps.disabled === nextProps.disabled;
  },
);
export default PromptSelectionActionBar;
