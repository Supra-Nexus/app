import AgentForm from './agent-form';

function AddAgentPage() {
  return <AgentForm mode="add" />;
}

export default AddAgentPage;
