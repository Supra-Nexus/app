import AgentForm from './agent-form';

function EditAgentPage() {
  return <AgentForm mode="edit" />;
}

export default EditAgentPage;
