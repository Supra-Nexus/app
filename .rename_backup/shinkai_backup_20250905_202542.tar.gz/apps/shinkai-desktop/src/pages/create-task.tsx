import CronTask from '../components/cron-task/component/cron-task';

export default function CreateTask() {
  return <CronTask mode="create" />;
}
